// This is just a sample app. You can structure your Neutralinojs app code as you wish.
// This example app is written with vanilla JavaScript and HTML.
// Feel free to use any frontend framework you like :)
// See more details: https://neutralino.js.org/docs/how-to/use-a-frontend-library

function showInfo() {
    document.getElementById('info').innerHTML = `
        ${NL_APPID} is running on port ${NL_PORT}  inside ${NL_OS}
        <br/><br/>
        <span>server: v${NL_VERSION} . client: v${NL_CVERSION}</span>
        `;
}

function openDocs() {
    Neutralino.os.open("https://neutralino.js.org/docs");
}

function openTutorial() {
    Neutralino.os.open("https://www.youtube.com/watch?v=txDlNNsgSh8&list=PLvTbqpiPhQRb2xNQlwMs0uVV0IN8N-pKj");
}

function setTray() {
    if(NL_MODE != "window") {
        console.log("INFO: Tray menu is only available in the window mode.");
        return;
    }
    let tray = {
        icon: "/resources/icons/trayIcon.png",
        menuItems: [
            {id: "VERSION", text: "Get version"},
            {id: "SEP", text: "-"},
            {id: "QUIT", text: "Quit"}
        ]
    };
    Neutralino.os.setTray(tray);
}

function onTrayMenuItemClicked(event) {
    switch(event.detail.id) {
        case "VERSION":
            Neutralino.os.showMessageBox("Version information",
                `Neutralinojs server: v${NL_VERSION} | Neutralinojs client: v${NL_CVERSION}`);
            break;
        case "QUIT":
            Neutralino.app.exit();
            break;
    }
}

function onWindowClose() {
    Neutralino.app.exit();
}

Neutralino.init();

Neutralino.events.on("trayMenuItemClicked", onTrayMenuItemClicked);
Neutralino.events.on("windowClose", onWindowClose);

if(NL_OS != "Darwin") { // TODO: Fix https://github.com/neutralinojs/neutralinojs/issues/615
    setTray();
}

showInfo();

const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
const currentTheme = localStorage.getItem('theme');

if (currentTheme) {
  document.documentElement.setAttribute('data-theme', currentTheme);

  if (currentTheme === 'dark') {
    toggleSwitch.checked = true;
  }
}

$('document').ready(function() {

	//Set default timer lengths (in seconds)
	var breakTime = 300;
	var sessionTime = 1500;

	//Set the countdown timer for the first Session 
	var clockTime = sessionTime;
	var clockType = 'session';
	
	//Tell the app that the clock isn't running
	var clockRunning = false;

	//Set an ID to use with setInterval and clearInterval
	var countdownID;

	//Functions to convert seconds to friendly formats
	var inMinSec = function(time) {
		var m = Math.floor(time/60);
		var s = time % 60;

		if (s < 10) {
			s = '0' + s.toString();
		}
		return m + ':' + s;
	};

	var inMinOnly = function(time) {
		return (time / 60).toFixed();
	}

	//Functions for pushing timer values to the UI in friendly formats
	var updateBreakIndicator = function() {
		$('#break-indicator').text(inMinOnly(breakTime));
	}

	var updateSessionIndicator = function() {
		$('#session-indicator').text(inMinOnly(sessionTime));
		if (clockType === 'session') {
			$('#clock-counter').text(inMinSec(sessionTime));
		}
	}

	var updateClockCounter = function() {
		$('#clock-counter').text(inMinSec(clockTime));
	}

	//Update the progress bar. 'Progress' should be an int from 0-100.
	var updateProgress = function(progress){
		progress = Math.abs(progress - 100).toFixed(2).toString() + '%';
	    $('#inner').height(progress);
	};

	//Initialize the UI
	var resetApp = function() {
		clockTime = sessionTime;
		clockType = 'session';
		updateBreakIndicator();
		updateSessionIndicator();
		updateClockCounter();
		updateProgress(100);
		$('#clock-label').text('Session');
		$('#clock-button').text('Start');
		$('#reset-button').attr('disabled', true);
	}

	resetApp();

	//Click Handlers for changing the break and session lengths.
	//If the clock is running, don't allow the times to be changed.
	$('#break-minus').on('click', function () {
		//If the clock is running, don't allow the times to be changed.
		if (clockRunning) {return;}

		//Don't allow negative time values
		if (breakTime > 0 && clockType === 'break') {
			breakTime -= 60;
			clockTime = breakTime;
			updateBreakIndicator();
			updateClockCounter();
		} else if (breakTime > 0) {
			//Increment the time by one minute
			breakTime -= 60;
			updateBreakIndicator();
		}
	});

	$('#break-plus').on('click', function () {
		if (clockRunning) {return;}

		if (clockType === 'break') {
			breakTime += 60;
			clockTime = breakTime;
			updateBreakIndicator();
			updateClockCounter();
		} else {
			breakTime += 60;
			updateBreakIndicator();
		}
	});

	$('#session-minus').on('click', function () {
		if (clockRunning) {return;}

		if (sessionTime > 0) {
			sessionTime -= 60;
			resetApp();
		}
	});

	$('#session-plus').on('click', function () {
		if (clockRunning) {return;}
		sessionTime += 60;
		resetApp();
	});


	//Timer function. When the session time runs out, switch to break time,
	//and vice-versa.
	var countdown = function() {
		if (clockTime > 0 && clockRunning) {
			clockTime -= 1;
			updateClockCounter();
			if (clockType === 'session') {
				updateProgress(clockTime / sessionTime * 100);		
			} else {
				updateProgress(clockTime / breakTime * 100);
			}
		} else if (clockTime === 0 && clockRunning) {
			if (clockType === 'session') {
				$('#clock-label').text('Break');
				clockType = 'break';
				clockTime = breakTime;
			} else if (clockType === 'break') {
				$('#clock-label').text('Session');
				clockType = 'session';
				clockTime = sessionTime;
			}
		}
	};

	//Start-Stop Click Handler
	$('#clock-button').on('click', function() {
		if (clockRunning) {
			clockRunning = false;
			window.clearInterval(countdownID);
			$('#clock-button').text('Resume');
			$('#reset-button').attr('disabled', false);
		} else {
			clockRunning = true;
			countdownID = window.setInterval(countdown, 1000);
			$('#clock-button').text('Pause');
			$('#reset-button').attr('disabled', true);
		}
	});

	//Reset Click Handler
	$('#reset-button').on('click', function() {
		resetApp();
	});

});